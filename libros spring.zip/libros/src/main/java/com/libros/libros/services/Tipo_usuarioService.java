package com.libros.libros.services;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.libros.libros.models.Tipo_usuario;
import com.libros.libros.repositories.Tipo_usuarioRepository;

@CrossOrigin
@RestController
public class Tipo_usuarioService {
    private final Tipo_usuarioRepository tipo_usuarioRepository;

    Tipo_usuarioService(Tipo_usuarioRepository tipo_usuarioRepository) {
        this.tipo_usuarioRepository = tipo_usuarioRepository;
    }

    @GetMapping("/tipo_usuarios")
    List<Tipo_usuario> getAll() {
        return tipo_usuarioRepository.getAll();
    }

    /*
    @PostMapping("/Categoria")
    @ResponseBody
    public Categoria crear(@RequestBody Categoria Categoria){
        Categoria resultado = CategoriaRepository.crear(Categoria);
        return resultado;
    }
    


    // get R
    @GetMapping("/Categoria")
    public List<Categoria> getAllCategorias(){
        return CategoriaRepository.getAll();
    }
    //get by
    @GetMapping("/Categoria/{id}")
    public List<Categoria> getCategoria(@PathVariable String id){
        return CategoriaRepository.show(id);
    }



    // actualizar U
    @PutMapping("/Categoria/{id}")
    @ResponseBody
    public String updateCategoria(@RequestBody Categoria Categoria, @PathVariable String id){
        String retorno = CategoriaRepository.update(Categoria,id);
        return retorno;
    }
    
    // borrar D
    @DeleteMapping("/Categoria/{id}")
    public void borrar(@PathVariable String id){
        CategoriaRepository.delete(id);
    }

    */
}
