package com.libros.libros.models;

public class Ubicacion {
	private Integer id_ubicacion;
	private String nombre_ubicacion;

    public Integer getId_ubicacion() {
        return id_ubicacion;
    }
    public void setId_ubicacion(Integer id_ubicacion) {
        this.id_ubicacion = id_ubicacion;
    }
    public String getNombre_ubicacion() {
        return nombre_ubicacion;
    }
    public void setNombre_ubicacion(String nombre_ubicacion) {
        this.nombre_ubicacion = nombre_ubicacion;
    }
}
