package com.libros.libros.models;

public class Ranking {
    private Integer id_ranking;
    private Integer id_libro;

    
    public Integer getId_ranking() {
        return id_ranking;
    }
    public void setId_ranking(Integer new_value) {
        this.id_ranking = new_value;
    }
    public Integer getId_libro() {
        return id_libro;
    }
    public void setId_libro(Integer new_value) {
        this.id_libro = new_value;
    }
}
